import torch

l1_loss = torch.nn.L1Loss
mse_loss = torch.nn.MSELoss
